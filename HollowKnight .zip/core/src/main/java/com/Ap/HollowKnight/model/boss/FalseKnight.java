package com.Ap.HollowKnight.model.boss;

import com.Ap.HollowKnight.controller.events.GameEvent;
import com.Ap.HollowKnight.controller.events.GameEventMessenger;
import com.Ap.HollowKnight.model.enemy.EnemyModel;
import com.Ap.HollowKnight.model.game.FacingDirection;
import com.Ap.HollowKnight.model.level.LevelModel;
import com.Ap.HollowKnight.model.map.Block;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import java.util.ArrayList;
import java.util.Random;

public class FalseKnight extends EnemyModel {
    private BossState currentState;
    private Class<? extends BossState> previousState;
    private FalseKnightPhase currentPhase;
    private Rectangle maceHitBox;
    private int spamCount = 0;
    private boolean isPhaseTwo = false;
    private int damageCounter = 0;
    private ArrayList<ShockWave> shockWaves = new ArrayList<>();
    private boolean bossBegins = false;
    private boolean firstStunned = false;
    private Random random = new Random();
    private static final int BASE_ARMOR_HP = 250;
    private static final float MAX_SPAM = 2;
    private static final int BASE_HP = 70;
    int cnt = 1;
    private int stunHitCounter = 0;

    private int currentArmorHp;
    private int currentHp;

    public FalseKnight(Vector2 position, Rectangle hitBox, Vector2 spawnPoint) {
        super(position, hitBox, spawnPoint, 60);
        currentState = new IdleState();
        currentArmorHp = BASE_ARMOR_HP;
        currentHp = BASE_HP;
        maceHitBox = new Rectangle(position.x, position.y, 180, 120);
        currentPhase = FalseKnightPhase.IDLE;
    }

    @Override
    public void update(float delta, ArrayList<Block> blocks) {
        if (!bossBegins && !(currentState instanceof IdleState) && !isDead()) {
            bossBegins = true;
            GameEventMessenger.getInstance().dispatch(GameEvent.ENTERED_BOSS_ROOM, null);
        }
        if (currentState != null) {
            currentState.update(this, LevelModel.getInstance().getKnight(), blocks, delta);
        }
        shockWaves.removeIf(shockWave -> !shockWave.isActive());
        Vector2 knightPos = LevelModel.getInstance().getKnight().getPosition();
        if (Vector2.dst(knightPos.x, knightPos.y, getPosition().x, getPosition().y) > 3000) {
            bossBegins = false;
        }
    }

    @Override
    protected void die() {
        super.die();
        for(ShockWave shockWave : shockWaves) {
            shockWave.setActive(false);
        }
    }

    @Override
    public void takeDamage(int amount) {
        if (currentState instanceof StunState) {
            currentHp -= amount;
            stunHitCounter++;

            if (currentHp <= 0) {
                GameEventMessenger.getInstance().dispatch(GameEvent.BOSS_DEFEATED, this);
                currentPhase = FalseKnightPhase.DEAD;
                die();
            } else if (stunHitCounter >= 3) {
                ((StunState) currentState).forceWakeUp();
            }
        } else {
            currentArmorHp -= amount;
            if (currentArmorHp <= BASE_ARMOR_HP / 2 && !firstStunned) {
                isPhaseTwo = true;
                firstStunned = true;
                stunHitCounter = 0;
                changeState(new StunState());
                GameEventMessenger.getInstance().dispatch(GameEvent.BOSS_STUN, null);
            } else if (currentArmorHp <= 0) {
                stunHitCounter = 0;
                changeState(new StunState());
                GameEventMessenger.getInstance().dispatch(GameEvent.BOSS_STUN, null);
            } else {
                damageCounter++;
            }
        }

        if (!(currentState instanceof StunState) && (damageCounter >= 3 || random.nextInt(100) >= 80)) {
            changeState(new DefensiveLeapState());
            damageCounter = 0;
        }

        GameEventMessenger.getInstance().dispatch(GameEvent.ENEMY_HURT, this);
    }
    public void changeState(BossState newState) {
        if (currentState != null) {
            previousState = currentState.getClass();
            currentState.exit(this);
        }
        currentState = newState;
        currentState.enter(this, LevelModel.getInstance().getKnight());
    }

    public void spawnShockwave() {
        float waveWidth = 90;
        float waveHeight = 200;

        float startX = (getFacingDirection() == FacingDirection.RIGHT)
            ? getHitBox().x + getHitBox().width + 10f
            : getHitBox().x - waveWidth - 10f;

        Vector2 spawnPos = new Vector2(startX, getHitBox().y);
        Rectangle hitBox = new Rectangle(startX, getHitBox().y, waveWidth, waveHeight);

        ShockWave wave = new ShockWave(spawnPos, hitBox, spawnPos, getFacingDirection());
        this.shockWaves.add(wave);

    }

    public BossState getBossCurrentState() {
        return currentState;
    }

    public void setCurrentState(BossState currentState) {
        this.currentState = currentState;
    }

    public Class<? extends BossState> getPreviousState() {
        return previousState;
    }

    public void setPreviousState(Class<? extends BossState> previousState) {
        this.previousState = previousState;
    }

    public int getSpamCount() {
        return spamCount;
    }

    public void setSpamCount(int spamCount) {
        this.spamCount = spamCount;
    }

    public boolean isPhaseTwo() {
        return isPhaseTwo;
    }

    public void setPhaseTwo(boolean phaseTwo) {
        isPhaseTwo = phaseTwo;
    }

    public int getDamageCounter() {
        return damageCounter;
    }

    public void setDamageCounter(int damageCounter) {
        this.damageCounter = damageCounter;
    }

    public Random getRandom() {
        return random;
    }

    public void setRandom(Random random) {
        this.random = random;
    }

    public int getCurrentArmorHp() {
        return currentArmorHp;
    }

    public void setCurrentArmorHp(int currentArmorHp) {
        this.currentArmorHp = currentArmorHp;
    }

    public int getCurrentHp() {
        return currentHp;
    }

    public void setCurrentHp(int currentHp) {
        this.currentHp = currentHp;
    }

    public Rectangle getMaceHitBox() {
        return maceHitBox;
    }

    public void setMaceHitBox(Rectangle maceHitBox) {
        this.maceHitBox = maceHitBox;
    }

    public FalseKnightPhase getCurrentPhase() {
        return currentPhase;
    }

    public void setCurrentPhase(FalseKnightPhase currentPhase) {
        this.currentPhase = currentPhase;
    }

    public ArrayList<ShockWave> getShockWaves() {
        return shockWaves;
    }
}
